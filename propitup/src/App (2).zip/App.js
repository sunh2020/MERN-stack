import logo from './logo.svg';
import './App.css';

import PersonCard from './components/PersonCard';

function App() {
  return (
    <div className="App">
      <PersonCard firstName={"Doe"}lastName={"Jane"}age={45}hairColor={"Black"}/>
      <button onClick={ ()=> alert("Birthday button for Jane") }>Birthday button for Jane</button>

      <PersonCard firstName={"Smith"}lastName={"John"}age={88}hairColor={"Brown"}/>
      <button onClick={ ()=> alert("Birthday button for John") }>Birthday button for John</button>


      <PersonCard firstName={"Fillmore"}lastName={"Millard"}age={50}hairColor={"Brown"}/>
      <button onClick={ ()=> alert("Birthday button for Millard") }>Birthday button for Millard</button>


      <PersonCard firstName={"Smith"}lastName={"Maria"}age={62}hairColor={"Brown"}/>
      <button onClick={ ()=> alert("Birthday button for Maria") }>Birthday button for Maria</button>
    </div>
  )
}

export default App;
